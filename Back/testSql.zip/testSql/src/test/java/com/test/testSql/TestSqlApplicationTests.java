package com.test.testSql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
