package com.test.testSql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSqlApplication.class, args);
	}

}
